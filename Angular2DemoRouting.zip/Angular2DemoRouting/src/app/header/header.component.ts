import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id.toString(),
    selector: '<app-header></app-header>',
    templateUrl: 'header.component.html'
})

export class HeaderComponent {
}