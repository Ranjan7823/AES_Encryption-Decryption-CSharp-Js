import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id.toString(),
    selector: '<app-footer></app-footer>',
    templateUrl: 'footer.component.html'
})

export class FooterComponent {
}