﻿using System;
using System.Threading;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        [System.Web.Services.WebMethod]         
        public static string GetText()
        {
            for (int i = 0; i < 10; i ++)
            {   
                // In actual projects this action may be a database operation.
                //For demsonstration I have made this loop to sleep.
                Thread.Sleep(2600);
            }
            return "Download Complete...";
        }        
    }
}
